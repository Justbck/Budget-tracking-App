//
//  Item.swift
//  ExpencesApp
//
//  Created by Justyna Bucko on 02/05/2021.
//

import Foundation

class Item: Codable {
    var amount: String = ""
    var due: Bool = false
}
