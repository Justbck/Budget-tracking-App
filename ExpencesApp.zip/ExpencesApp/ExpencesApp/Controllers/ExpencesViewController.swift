//
//  ViewController.swift
//  ExpencesApp
//
//  Created by Justyna Bucko on 01/05/2021.
//

import UIKit

class ExpencesViewController: UITableViewController {
    
    var itemArray = [Item]()
    
    let defaults = UserDefaults.standard

    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        
        //if let items = defaults.array(forKey: "ExpencesArray") as? [String] {
          //  itemArray = items
        //}
    }
    
   
    //tableview datasource methods
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemArray.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "ExpenceItemCell", for: indexPath)
        
        let item = itemArray[indexPath.row]
        
        
        cell.textLabel?.text = item.amount
        
        //ternary operator
        cell.accessoryType = item.due ? .checkmark : .none
        
        return cell
    }
    
    
    //tableview delegate methods
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        itemArray[indexPath.row].due = !itemArray[indexPath.row].due

        tableView.reloadData()
        tableView.deselectRow(at: indexPath, animated: true)
        
    }
    
    
    @IBAction func addButtonPressed(_ sender: UIBarButtonItem) {
        
        var amountTextField = UITextField()
        
        let alert = UIAlertController(title: "Add Expence", message: "", preferredStyle: .alert)
        
        let action = UIAlertAction(title: "Add", style: .default) { (action) in
            //what will happen
            
            let newItem = Item()
            newItem.amount = amountTextField.text!
            self.itemArray.append(newItem)
            
            self.defaults.setValue(self.itemArray, forKey: "ExpencesArray")
            self.tableView.reloadData()
        }
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
    
    
        
        alert.addTextField { (alertTextField) in
            alertTextField.placeholder = "Amount: "
            amountTextField = alertTextField
        }
        
        
        alert.addAction(action)
        alert.addAction(cancel)
        
        present(alert, animated: true, completion: nil)
    }
    
}

